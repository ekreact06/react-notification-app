/** @format */

import React, { useState } from "react";
import { Button, Card } from "react-bootstrap";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const CustomNotification = (props) => {
	const bgColor = props.bgcolor;
	const [isRead, setRead] = useState(false);
	const toggleRead = () => {
		setRead(!isRead);
	};
	return (
		<div className="d-flex flex-column" style={{ verticalAlign: "left" }}>
			<div
				onClick={toggleRead}
				style={{
					width: "380px",
					height: "98px",
					backgroundColor: bgColor,
					color: "white",
				}}>
				<div style={{ fontWeight: "bold" }}>{isRead ? "Read" : "Unread"}</div>
				<div style={{ borderTop: "1px solid" }}></div>

				<div style={{ fontWeight: "bold" }}>Dianne left a comment</div>
				<div>Can you review this MR?</div>
			</div>
		</div>
	);
};

function App() {
	let bgcolor = "";
	const toastId = React.useRef(null);
	const [color, setColor] = useState("");
	const notify = (event) => {
		bgcolor = event.target.value;
		toast.dismiss(toastId.current);
		setColor(bgcolor);
		toastId.current = toast(<CustomNotification bgcolor={bgcolor} />, {
			position: toast.POSITION.BOTTOM_RIGHT,
			autoClose: 8000,
		});
	};

	return (
		<div className="container pt-4">
			<div className="row">
				<div className="col text-center">
					<Button
						className="m-2"
						value="blue"
						onClick={notify}
						style={{
							backgroundColor: "blue",
							width: "120px",
						}}>
						Blue
					</Button>
					<Button
						className="m-2"
						value="green"
						onClick={notify}
						style={{
							backgroundColor: "green",
							width: "120px",
						}}>
						Green
					</Button>
					<Button
						className="m-2"
						value="grey"
						onClick={notify}
						style={{
							backgroundColor: "grey",
							width: "120px",
						}}>
						Grey
					</Button>
					<Button
						className="m-2"
						value="orange"
						onClick={notify}
						style={{
							backgroundColor: "orange",
							width: "120px",
						}}>
						Orange
					</Button>
					<ToastContainer toastStyle={{ backgroundColor: color }} />
				</div>
			</div>
		</div>
	);
}

export default App;
