/** @format */

import React, { useState } from "react";

export const CustomNotification = (props) => {
	const bgColor = props.bgcolor;
	const [isRead, setRead] = useState(false);
	const toggleRead = () => {
		setRead(!isRead);
	};
	return (
		<div className="d-flex flex-column" style={{ verticalAlign: "left" }}>
			<div
				onClick={toggleRead}
				style={{
					width: "380px",
					height: "98px",
					backgroundColor: bgColor,
					color: "white",
				}}>
				<div style={{ fontWeight: "bold" }}>{isRead ? "Read" : "Unread"}</div>
				<div style={{ borderTop: "1px solid" }}></div>

				<div style={{ fontWeight: "bold" }}>Dianne left a comment</div>
				<div>Can you review this MR?</div>
			</div>
		</div>
	);
};
